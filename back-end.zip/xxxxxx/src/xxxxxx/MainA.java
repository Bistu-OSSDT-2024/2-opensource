package xxxxxx;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.BytesRefIterator;
import org.apache.lucene.util.BytesRefIterator.WithOffs;
import org.apache.lucene.util.BytesRefIterator.WithPositions;
import org.apache.lucene.util.BytesRefIterator.WithTermVector;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainA {

    // ʾ�����ڴ������洢
    private Directory index;

    public MainA() {
        index = new RAMDirectory();
    }

    // �����ĵ�������
    public void addDocument(String content) throws IOException {
        Analyzer analyzer = new StandardAnalyzer();
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        IndexWriter writer = new IndexWriter(index, config);

        Document doc = new Document();
        doc.add(new org.apache.lucene.document.TextField("content", content, Document.Store.YES));
        writer.addDocument(doc);

        writer.close();
    }

    // ��ȡ�ؼ���
    public List<String> extractKeywords(String query, int numKeywords) throws IOException {
        IndexReader reader = DirectoryReader.open(index);
        IndexSearcher searcher = new IndexSearcher(reader);

        // ������ѯ�ı�������
        Query luceneQuery = new TermQuery(new Term("content", query));
        TopDocs topDocs = searcher.search(luceneQuery, numKeywords);

        List<String> keywords = new ArrayList<>();
        for (ScoreDoc scoreDoc : topDocs.scoreDocs) {
            Document doc = searcher.doc(scoreDoc.doc);
            String keyword = doc.get("content");
            keywords.add(keyword);
        }

        reader.close();

        return keywords;
    }

    public static void main(String[] args) throws IOException {
    	MainA extractor = new MainA();

        // ����ʾ���ĵ�������
        extractor.addDocument("Example document for keyword extraction.");
        extractor.addDocument("Another example for testing keyword extraction.");

        // ��ȡ�ؼ���
        List<String> keywords = extractor.extractKeywords("example", 5);
        System.out.println("Keywords: " + keywords);
    }
}

