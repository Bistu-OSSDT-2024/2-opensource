package xxxxxx;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.SimpleTokenizer;
import opennlp.tools.util.Span;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class KeywordExtractionExample {

    public static void main(String[] args) throws IOException {

        String text = "Apache OpenNLP is an open-source library.";

        String[] tokens = SimpleTokenizer.INSTANCE.tokenize(text);

        InputStream posModelIn = new FileInputStream("en-pos-maxent.bin");
        POSModel posModel = new POSModel(posModelIn);
        POSTaggerME posTagger = new POSTaggerME(posModel);

        String[] tags = posTagger.tag(tokens);

        List&lt;String&gt; keywords = extractKeywords(tokens, tags);

        System.out.println("Keywords: " + keywords);

        posModelIn.close();
    }


    private static List&lt;String&gt; extractKeywords(String[] tokens, String[] tags) {
        List&lt;String&gt; nounTags = Arrays.asList("NN", "NNS", "NNP", "NNPS");
        List&lt;String&gt; keywords = new ArrayList&lt;&gt;();

        for (int i = 0; i &lt; tokens.length; i++) {
            if (nounTags.contains(tags[i])) {
                keywords.add(tokens[i]); 
            }
        }

        return keywords;
    }
}